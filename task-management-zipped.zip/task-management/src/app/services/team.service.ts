// team.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class TeamService {
  private baseUrl = 'http://localhost:3000/api/teams';

  constructor(private http: HttpClient) { }

  getAllTeams(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

  createTeam(teamData: Team): Observable<any> {
    return this.http.post(`${this.baseUrl}`, teamData);
  }

  addMember(teamId: string, memberId: string): Observable<any> {
    return this.http.put(`${this.baseUrl}/${teamId}/add-member/${memberId}`, {});
  }

  fetchTeamSearchList(searchTerm: string): Observable<Team[]> {
    return this.http.get<Team[]>(`${this.baseUrl}/search?term=${searchTerm}`);
  }

  getTeamMembers(teamName: string): Observable<User[]> {
    return this.http.get<User[]>(`${this.baseUrl}/members/${teamName}`);
  }
  
}

export interface Team{
  name: string;
  members: User[];
}