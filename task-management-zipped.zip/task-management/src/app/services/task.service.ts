import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Team } from './team.service';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private apiUrl = 'http://localhost:3000/api/tasks';  

  constructor(private http: HttpClient) { }

  getAllTasks(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}`).pipe(
      catchError((error: any) => {
        throw error;
      })
    );
  }

  createTask(taskData: Task): Observable<any> {
    return this.http.post(`${this.apiUrl}`, taskData).pipe(
      catchError((error: any) => {
        throw error;
      })
    );
  }

  getTasksByTeam(teamName: string): Observable<Task[]> {
    return this.http.get<Task[]>(`${this.apiUrl}/team/${teamName}`);
  }
}

export interface Task {
  name: string;
  team: Team;
}