import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'http://localhost:3000/api/users'; // Replace with your actual API URL

  constructor(private http: HttpClient) { }

  createUser(userData: User): Observable<any> {
    console.log(userData);
    return this.http.post(`${this.apiUrl}`, userData);
  }

  getAllUsers(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}`);
  }

  fetchSearchList(searchTerm: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/search?term=${searchTerm}`);
  }
}

export interface User{
  name: string;
  email: string;
}
