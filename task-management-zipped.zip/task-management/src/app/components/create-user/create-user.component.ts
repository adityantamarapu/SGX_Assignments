import { Component } from '@angular/core';
import { User, UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent {
  userData: User = {
    name: '',
    email: '',
  };

  constructor(private userService: UserService) {}

  createUser() {
    if(this.userData.name === '' || this.userData.email === '') return;

    this.userService.createUser(this.userData).subscribe(
      response => {
        // Handle successful user creation
        console.log('User created successfully:', response);
        this.userData.name = '';
        this.userData.email = '';
      },
      error => {
        // Handle error
        console.error('Error creating user:', error);
      }
    );
  }
}
