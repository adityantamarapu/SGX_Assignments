import { Component, OnInit } from '@angular/core';
import { Team, TeamService } from 'src/app/services/team.service';
import { User, UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-create-team',
  templateUrl: './create-team.component.html',
  styleUrls: ['./create-team.component.css']
})
export class CreateTeamComponent implements OnInit {
  teamName: string = '';
  employees: User[] = [];
  filteredEmployees: User[] = [];
  showDropdown: boolean = false;
  members: User[] = [];
  searchTerm: string = '';
  errorMessage: string = '';

  constructor(private userService: UserService, private teamService: TeamService) { }

  ngOnInit(): void {

  }

  fetchSearchList(): void {
    if (!this.searchTerm) {

      this.filteredEmployees = [];
    } else {

      this.userService.fetchSearchList(this.searchTerm).subscribe(
        (users: User[]) => {
          this.filteredEmployees = users;
        },
        (error) => {
          console.error('Error fetching search list:', error);
        }
      );
    }

    this.showDropdown = !!this.filteredEmployees.length;
  }

  addMember(employee: User): void {
    // Add selected employee to the members array
    this.members.push(employee);
    // Clear the search term and filtered list after adding member
    this.searchTerm = '';
    this.filteredEmployees = [];
  }

  // filterEmployees(): void {
  //   if (!this.searchTerm) {

  //     this.filteredEmployees = this.employees;
  //     // this.showDropdown = false;
  //   } else {

  //     // this.filteredEmployees = this.employees.filter(employee =>
  //     //   employee.name.toLowerCase().includes(this.searchTerm.toLowerCase())
  //     // );

  //     this.fetchSearchList();
  //   }

  //   this.showDropdown = true;
  // }

  createTeam(): void {
    const teamData: Team = { name: this.teamName, members: this.members };
    
    this.teamService.createTeam(teamData).subscribe(
      (response: any) => {
        console.log('Team created successfully:', response);
        
        this.teamName = '';
        this.members = [];
      },
      (error) => {
        this.errorMessage = 'An error occurred while creating the team.';
        console.error('Error creating team:', error);
      }
    );

  }

  removeMember(member: User): void {
    const index = this.members.indexOf(member);
    if (index !== -1) {
      this.members.splice(index, 1);
    }
  }

}
