import { Component, OnInit } from '@angular/core';
import { Task, TaskService } from 'src/app/services/task.service';
import { Team, TeamService } from 'src/app/services/team.service';

@Component({
  selector: 'app-create-task',
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.css']
})
export class CreateTaskComponent implements OnInit {
  taskName: string = '';
  team: Team | null = null;
  searchTerm: string = '';
  showDropdown: boolean = false;
  filteredTeams: Team[] = [];

  constructor(private taskService: TaskService, private teamService: TeamService) { }

  ngOnInit(): void {
  }

  fetchTeamSearchList(): void {
    if (!this.searchTerm) {

      this.filteredTeams = [];
    } else {

      this.teamService.fetchTeamSearchList(this.searchTerm).subscribe(
        (users: Team[]) => {
          this.filteredTeams = users;
        },
        (error) => {
          console.error('Error fetching search list:', error);
        }
      );
    }

    this.showDropdown = !!this.filteredTeams.length;
  }

  assignTask(team: Team): void {
    this.team = team;
    this.showDropdown = false;
  }

  removeTeam(): void {
    this.team = null;
  }

  createTask(): void {
    if (!this.taskName || !this.team) {
      console.error('Task name and team are required.');
      return;
    }

    const taskData: Task= {name: this.taskName, team: this.team};

    // Call TaskService to create a task with the given name and assigned team
    this.taskService.createTask(taskData).subscribe(
      (response: any) => {
        console.log('Task created successfully:', response);
        // Optionally, you can reset form fields or navigate to another page
        // Reset form fields
        this.taskName = '';
        this.team = null;
      },
      (error) => {
        console.error('Error creating task:', error);
        // Handle error, show error message to the user, etc.
      }
    );
  }

}
