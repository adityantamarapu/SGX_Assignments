import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Team, TeamService } from 'src/app/services/team.service';
import { User } from 'src/app/services/user.service';

@Component({
  selector: 'app-team-list',
  templateUrl: './team-list.component.html',
  styleUrls: ['./team-list.component.css']
})
export class TeamListComponent implements OnInit {
  teams: any[]= [];

  constructor(private teamService: TeamService, private router: Router) { }

  ngOnInit(): void {
    this.fetchAllTeams();
  }

  fetchAllTeams(): void {
    this.teamService.getAllTeams().subscribe(
      (teams: any[]) => {
        this.teams = teams;

        console.log('team list fetchAllTeams says: ', teams);
      },
      (error) => {
        console.error('Error fetching teams:', error);
      }
    );
  }

  viewTeamDetail(name: string): void {
    // name is teamId here
    this.router.navigate(['/teams',name ]);
  }
}
