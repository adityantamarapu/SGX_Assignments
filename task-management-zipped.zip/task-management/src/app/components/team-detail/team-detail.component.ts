import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Task, TaskService } from 'src/app/services/task.service';
import { TeamService } from 'src/app/services/team.service';
import { User } from 'src/app/services/user.service';

@Component({
  selector: 'app-team-detail',
  templateUrl: './team-detail.component.html',
  styleUrls: ['./team-detail.component.css']
})
export class TeamDetailComponent implements OnInit {
  teamName!: string;
  users!: User[];
  tasks: Task[] = [];
  showTasksTable: boolean = false;
  
  constructor(private route: ActivatedRoute, private teamService: TeamService, private taskService: TaskService) { }

  ngOnInit(): void {
    // Access route parameters to get team details
    this.route.params.subscribe(params => {
      // Access the teamName parameter from the route
      this.teamName = params['name'];

      // Call the team service to fetch members of the team
      this.teamService.getTeamMembers(this.teamName).subscribe(
        (members: User[]) => {
          // Assign the fetched members to the component property
          this.users = members;

          console.log('Team details says: ', this.users);
        },
        (error) => {
          console.error('Error fetching team members:', error);
        }
      );
    });

    
  }

  toggleTasksTable(): void {

    this.showTasksTable = !this.showTasksTable;

    this.taskService.getTasksByTeam(this.teamName).subscribe(
      (tasks: Task[]) => {
        
        this.tasks = tasks;
      },
      (error) => {
        console.error('Error fetching tasks assigned to the team:', error);
      }
    );
  }

}
