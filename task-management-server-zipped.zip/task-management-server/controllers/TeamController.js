const TeamService = require('../services/TeamService');

class TeamController {
    async getAllTeams(req, res) {
        try {
            const teams = await TeamService.getAllTeams();
            res.status(200).json(teams);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async createTeam(req, res) {
        try {
            const teamData = req.body;

            const members = [];

            teamData.members.forEach(element => {
                members.push(element._id);
            });

            teamData.members = members;

            console.log('create team controller says: ', teamData);

            const teamId = await TeamService.createTeam(teamData);

            res.status(201).json({ teamId });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async addMember(req, res) {
        try {
            const { teamId, memberId } = req.params;

            // Call the TeamService to add the member to the team
            await TeamService.addMember(teamId, memberId);

            res.status(200).json({ message: 'Member added successfully' });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async getTeamSearchList(req, res) {
        try {
            const searchTerm = req.query.term;
            // Call the UserService to fetch filtered users based on the search term
            const filteredTeams = await TeamService.getTeamSearchList(searchTerm);
            res.status(200).json(filteredTeams);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async getTeamMembersByTeamName(req, res) {
        try {
            const teamName = req.params.teamName;
            
            const teamMembers = await TeamService.getTeamMembersByTeamName(teamName);

            console.log('getTeamMembers says: ',teamMembers);
            res.status(200).json(teamMembers);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = new TeamController();
