//controllers/RecordingController.js

const RecordingService = require('../services/RecordingService');

class RecordingController{

    async uploadRecording(req,res){
        try{

            //console.log('RecordingController uploadRecording: ', req);

            const file = req.files.file;
            const uploadDate = req.fields.uploadDate;
            const username = req.fields.username;
            const uploadTime = req.fields.uploadTime;
            const ipAddress = req.fields.ipAddress;
            const applicationName = req.fields.applicationName;
    
            console.log('RecordingController uploadRecording: ', file, uploadDate, username, uploadTime, ipAddress, applicationName);
    
            await RecordingService.uploadRecording(file, uploadDate, username, uploadTime, ipAddress, applicationName);
            
            res.status(200).send('Recording uploaded successfully.');            
        }catch(err){

            console.log('RecordingController uploadRecording: ', err);
            res.status(500).json({error: err.message});
        }
    }

    async getAllRecordings(req, res) {
        try {
            // Call the service method to get all recordings
            const recordings = await RecordingService.getAllRecordings();
            
            console.log('RecordingController getAllRecordings: ', recordings);

            // Send the recordings as response
            res.status(200).json(recordings);
        } catch (error) {
            console.log('RecordingController getAllRecordings: ', error);
            res.status(500).json({ error: error.message });
        }
    }

    async downloadRecording(req, res){
        try {
            const fileName = req.params.fileName;

            console.log('RecordingController downloadRecording: ', fileName);

            // Call the service method to get file data based on filename
            const fileData = await RecordingService.getRecordingData(fileName);

            // console.log('RecordingController downloadRecording: ', fileData);

            if (!fileData) {
                return res.status(404).send('File not found');
            }

            // Set the response headers for file download
            res.set({
                'Content-Disposition': `attachment; filename="${fileName}"`,
                'Content-Type': 'application/octet-stream'
            });

            // Send the file data as response
            res.send(fileData);
        } catch (error) {
            console.log('RecordingController downloadRecording: ', error);
            res.status(500).json({ error: error.message });
        }
    }
}
 
module.exports = new RecordingController();
