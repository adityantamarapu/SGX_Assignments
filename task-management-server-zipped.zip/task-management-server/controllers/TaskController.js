//controllers/TaskController.js

const TaskService = require('../services/TaskService');

class TaskController {
    async getAllTasks(req, res) {
        try {
            
            const tasks = await TaskService.getAllTasks();
            res.status(200).json(tasks);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async createTask(req, res) {
        try {
            const taskData = req.body;

            taskData.team = taskData.team.name;

            const taskId = await TaskService.createTask(taskData);
            
            res.status(201).json({ taskId });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async getTasksByTeamName(req, res) {
        try {
            const teamName = req.params.teamName;

            console.log('task controller get tasks by team name says: ', teamName);

            const tasks = await TaskService.getTasksByTeam(teamName);

            console.log('task controller get tasks by team name says: ', tasks);
            res.status(200).json(tasks);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    // async getTaskSearchList(req, res) {
    //     try {
    //         const searchTerm = req.query.term;
    //         // Call the TaskService to fetch filtered tasks based on the search term
    //         const filteredTasks = await TaskService.getSearchList(searchTerm);
    //         res.status(200).json(filteredTasks);
    //     } catch (error) {
    //         res.status(500).json({ error: error.message });
    //     }
    // }
}

module.exports = new TaskController();
