//controllers/UserController.js

const UserService = require('../services/UserService');

class UserController {
    async getAllUsers(req, res) {
        try {
            
            const users = await UserService.getAllUsers();
            res.status(200).json(users);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async createUser(req, res) {
        try {
            const userData = req.body;

            const userCount = await UserService.countUsers();

            userData.empId = 'SG'+ Number(userCount + 1);

            const userId = await UserService.createUser(userData);
            
            res.status(201).json({ userId });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async getUserSearchList(req, res) {
        try {
            const searchTerm = req.query.term;
            // Call the UserService to fetch filtered users based on the search term
            const filteredUsers = await UserService.getSearchList(searchTerm);
            res.status(200).json(filteredUsers);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = new UserController();
