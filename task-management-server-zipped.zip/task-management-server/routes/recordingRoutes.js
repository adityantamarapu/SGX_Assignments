// recordingRoutes.js

const express = require('express');
const router = express.Router();
const recordingController = require('../controllers/RecordingController')

const multer = require('multer');
const storage = multer.memoryStorage();
const upload = multer({ storage });

// POST upload recording
router.post('/upload',upload.single('file'), recordingController.uploadRecording);
router.get('/', recordingController.getAllRecordings);
router.get('/download/:fileName', recordingController.downloadRecording);

module.exports = router;