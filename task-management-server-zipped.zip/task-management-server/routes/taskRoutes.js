// routes/taskRoutes.js

const express = require('express');
const router = express.Router();
const taskController = require('../controllers/TaskController')

// GET all tasks
router.get('/', taskController.getAllTasks);

// POST create task
router.post('/', taskController.createTask);

// GET tasks by team name
router.get('/team/:teamName', taskController.getTasksByTeamName);

// GET search tasks 
// router.get('/search', taskController.getTaskSearchList);

module.exports = router;
