// routes/teamRoutes.js

const express = require('express');
const router = express.Router();
const teamController = require('../controllers/TeamController');

// GET all teams
router.get('/', teamController.getAllTeams);

// POST create team
router.post('/', teamController.createTeam);

// PUT add member to team
router.put('/:teamId/add-member/:memberId', teamController.addMember);

// GET search teams
router.get('/search', teamController.getTeamSearchList);

// GET team members by team name
router.get('/members/:teamName', teamController.getTeamMembersByTeamName);

module.exports = router;
