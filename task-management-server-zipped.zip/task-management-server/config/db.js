// config/db.js

const { MongoClient, ServerApiVersion } = require('mongodb');

const credentials = 'C:/Users/AdityanTamarapu/NodeLearn/task-management-server/config/X509-cert-2928260931992466487.pem';

const client = new MongoClient('mongodb+srv://cluster0.8wfmwn2.mongodb.net/?authSource=%24external&authMechanism=MONGODB-X509&retryWrites=true&w=majority', {
  tlsCertificateKeyFile: credentials,
  serverApi: ServerApiVersion.v1
});

const getClient = async () => {
    try {
      console.log('Connecting to MongoDB Atlas...');
      return await client.connect();
    } catch (err) {
      console.error('Error connecting to MongoDB Atlas:', err);
    }
  };

  
  
  module.exports = {getClient};



 