//app.js

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const userRoutes = require('./routes/userRoutes');
const teamRoutes = require('./routes/teamRoutes');
const taskRoutes = require('./routes/taskRoutes');
const recordingRoutes = require('./routes/recordingRoutes');
const expressFormidable = require("express-formidable");

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(cors());
app.use(expressFormidable());
// app.set("view engine", "ejs")

// Routes
app.use('/api/users', userRoutes);
app.use('/api/teams', teamRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/recordings',recordingRoutes);
module.exports = app;
