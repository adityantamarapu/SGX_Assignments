//models/Task.js

const getClient = require("../config/db");

let client = null;

async function getTaskCollection() {
  try {
    client = await getClient();
    const database = client.db("task_management");
    return database.collection("tasks");
  } catch (err) {
    console.error('Error getting collection ', err);
    throw err;
  }
}

async function getAllTasks() {
  try {
    const collection = await getTaskCollection();
    const tasks = await collection.find().toArray();
    console.log('getAllTasks says: ', tasks);

    return tasks;
  } catch (error) {
    console.error('Error retrieving tasks:', error);
    throw error;
  } finally {
    await client.close();
  }
}

async function addNewTask(task) {
  try {
    const collection = await getTaskCollection();
    const result = await collection.insertOne(task);
    console.log(`Task added with ID: ${result.insertedId}`);
    return result.insertedId;
  } catch (error) {
    console.error('Error adding task:', error);
    throw error;
  } finally {
    await client.close();
  }
}

async function countTasks() {
  try {
    const collection = await getTaskCollection();
    const count = await collection.countDocuments();
    return count;
  } catch (error) {
    console.error('Error counting tasks:', error);
    throw error;
  } finally {
    if (client) {
      await client.close();
    }
  }
}

async function getSearchList(searchTerm) {
  try {
    const collection = await getTaskCollection();
    const filteredTasks = await collection.find({ name: { $regex: searchTerm, $options: 'i' } }).toArray();
    return filteredTasks;
  } catch (error) {
    console.error('Error fetching search list:', error);
    throw error;
  }finally {
    if (client) {
      await client.close();
    }
  }
}

async function getTasksByTeamName(teamName) {
    try {
      const collection = await getTaskCollection();
      const tasks = await collection.find({ 'team': teamName }).toArray();
      return tasks;
    } catch (error) {
      console.error('Error fetching tasks by team name:', error);
      throw error;
    }
    finally {
        if (client) {
          await client.close();
        }
      }
  }

module.exports = { getAllTasks, addNewTask, countTasks, getSearchList , getTasksByTeamName};
