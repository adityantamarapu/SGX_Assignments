//models/Recording.js

const { getClient } = require("../config/db");

const fs = require('fs');
const path = require('path');

let client = null;

async function uploadRecording(file, uploadDate, username, uploadTime, ipAddress, applicationName) {
    try {
        // Ensure that the required parameters are provided
        if (!file || !uploadDate || !username || !uploadTime || !ipAddress || !applicationName) {
            throw new Error('Missing required parameters');
        }

        // Assuming getClient() and other required functions are defined elsewhere
        client = await getClient();

        const fileName = file.name;
        const filePath = file.path;

        const database = client.db("recordings_db");
        const collection = database.collection('uploadedRecordings');

        const fileData = fs.readFileSync(filePath);
        
        // Insert the recording metadata into the collection
        await collection.insertOne({ 
            fileName: fileName, 
            data: fileData, 
            uploadDate: uploadDate, 
            username: username, 
            uploadTime: uploadTime, 
            ipAddress: ipAddress, 
            applicationName: applicationName 
        });

        // Delete uploaded file from server
        fs.unlinkSync(filePath);
    } catch (err) {
        console.log('Recording uploadRecording: ', err);
        throw err;
    } finally {
        await client.close();
    }
}


async function getAllRecordings() {
    try {
        client = await getClient();

        const database = client.db("recordings_db");
        const collection = database.collection('uploadedRecordings');

        // Retrieve all recordings from the collection
        const recordings = await collection.find().toArray();

        // Extract necessary information from each recording
        const recordingsInfo = recordings.map(record => ({
            fileName: record.fileName,
            applicationName: record.applicationName,
            ipAddress: record.ipAddress,
            username: record.username,
            date: record.uploadDate,
            time: record.uploadTime
        }));

        return recordingsInfo;
    } catch (err) {
        console.log('Recording getAllRecordings: ', err);
        throw err;
    } finally {
        await client.close();
    }
}

async function getRecordingData(fileName){
    try {
        client = await getClient();

        const database = client.db("recordings_db");
        const collection = database.collection('uploadedRecordings');

        console.log('Recording getRecordingData: ', fileName);

        // Find the recording by its filename
        const recording = await collection.findOne({ fileName: fileName });

        if (!recording) {
            throw new Error('Recording not found');
        }

        
        // Decode the Base64 data
        const fileData = Buffer.from(recording.data.buffer, 'base64');

        return fileData; // Return the file data
    } catch (err) {
        console.log('Recording getRecordingData: ', err);
        throw err;
    } finally {
        await client.close();
    }
}


module.exports = { uploadRecording, getAllRecordings , getRecordingData};