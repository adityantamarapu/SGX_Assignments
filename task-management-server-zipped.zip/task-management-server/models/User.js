//models/User.js

const getClient = require("../config/db");

let client = null;

async function getUserCollection() {
  try {
    client = await getClient();
    const database = client.db("task_management");
    return database.collection("users");
  } catch (err) {
    console.error('Error getting collection ', err);
    throw err;
  }
}

async function getAllUsers() {
  try {
    const collection = await getUserCollection();
    const users = await collection.find().toArray();
    console.log('getAllUsers says: ', users);

    return users;
  } catch (error) {
    console.error('Error retrieving users:', error);
    throw error;
  } finally {
    await client.close();
  }
}

async function addNewUser(user) {
  try {
    const collection = await getUserCollection();
    const result = await collection.insertOne(user);
    console.log(`User added with ID: ${result.insertedId}`);
    return result.insertedId;
  } catch (error) {
    console.error('Error adding user:', error);
    throw error;
  } finally {
    await client.close();
  }
}

async function countUsers() {
  try {
    const collection = await getUserCollection();
    const count = await collection.countDocuments();
    return count;
  } catch (error) {
    console.error('Error counting users:', error);
    throw error;
  } finally {
    // Close the client connection
    if (client) {
      await client.close();
    }
  }
}

async function getSearchList(searchTerm) {
  try {
    const collection = await getUserCollection();
    const filteredUsers = await collection.find({ name: { $regex: searchTerm, $options: 'i' } }).toArray();
    return filteredUsers;
  } catch (error) {
    console.error('Error fetching search list:', error);
    throw error;
  }
}

module.exports = { getAllUsers, addNewUser, countUsers, getSearchList, getUserCollection };
