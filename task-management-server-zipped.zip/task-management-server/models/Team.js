const getClient = require("../config/db");
const { getUserCollection } = require('../models/User');
const {  ObjectId } = require('mongodb');

let client = null;

async function getTeamCollection() {
    try {
        client = await getClient();
        const database = client.db("task_management");
        return database.collection("teams");
    } catch (err) {
        console.error('Error getting team collection ', err);
        throw err;
    }
}

async function getAllTeams() {
    try {
        const collection = await getTeamCollection();
        const teams = await collection.find().toArray();
        console.log('getAllTeams says: ', teams);

        return teams;
    } catch (error) {
        console.error('Error retrieving teams:', error);
        throw error;
    } finally {
        await client.close();
    }
}

async function addNewTeam(team) {
    try {
        const collection = await getTeamCollection();

        // Check if a team with the same name already exists
        const existingTeam = await collection.findOne({ name: team.name });
        if (existingTeam) {
            throw new Error('Team name already exists');
        }

        const result = await collection.insertOne(team);
        console.log(`Team added with ID: ${result.insertedId}`);
        return result.insertedId;
    } catch (error) {
        console.error('Error adding team:', error);
        throw error;
    } finally {
        await client.close();
    }
}


async function countTeams() {
    try {
        const collection = await getTeamCollection();
        const count = await collection.countDocuments();
        return count;
    } catch (error) {
        console.error('Error counting teams:', error);
        throw error;
    } finally {
        // Close the client connection
        if (client) {
            await client.close();
        }
    }
}

async function addMember(teamId, memberId) {
    try {
        const collection = await getTeamCollection();
        const teamObjectId = new ObjectID(teamId);
        const memberObjectId = new ObjectID(memberId);

        const result = await collection.updateOne(
            { _id: teamObjectId },
            { $addToSet: { members: memberObjectId } }
        );

        if (result.modifiedCount === 0) {
            throw new Error('Team not found or member already exists in the team.');
        }

        console.log(`Member added to team with ID: ${teamId}`);
        return teamId;
    } catch (error) {
        console.error('Error adding member to team:', error);
        throw error;
    } finally {
        await client.close();
    }
}

async function getTeamSearchList(searchTerm) {
    try {
        const collection = await getTeamCollection();
        const filteredTeams = await collection.find({ name: { $regex: searchTerm, $options: 'i' } }).toArray();
        return filteredTeams;
    } catch (error) {
        console.error('Error fetching search list:', error);
        throw error;
    }
}

async function getTeamMembersByTeamName(teamName) {
    try {
        const collection = await getTeamCollection();
        const team = await collection.findOne({ name: teamName });
        if (!team) {
            throw new Error('Team not found');
        }

        console.log('Team getTeamMembersByTeamName says: ', team.members);

        const memberIds = team.members.map(memberId => new ObjectId(memberId));

        console.log('Team getTeamMembersByTeamName says: ', memberIds);
        const userCollection = await getUserCollection();
        const users = await userCollection.find({ _id: { $in: memberIds } }).toArray();
        return users;
    } catch (error) {
        console.error('Error fetching team members by team name:', error);
        throw error;
    } finally {
        await client.close();
    }
}


module.exports = { getAllTeams, addNewTeam, addMember, getTeamSearchList, getTeamMembersByTeamName };
