//services/TaskService.js

const {uploadRecording, getAllRecordings, getRecordingData } = require('../models/Recording')

class RecordingService{

    async uploadRecording(file, uploadDate, username, uploadTime, ipAddress, applicationName){
        try {
           await uploadRecording(file, uploadDate, username, uploadTime, ipAddress, applicationName);
        } catch (error) {
            throw new Error('Failed to upload recording to database');
        }
    }

    async getAllRecordings() {
        try {
            // Call the model method to retrieve all recordings
            const recordings = await getAllRecordings();
            return recordings;
        } catch (error) {
            throw new Error('Failed to get recordings');
        }
    }

    async getRecordingData(fileName){
        try {
            // Call the model method to retrieve file data based on filename
            const fileData = await getRecordingData(fileName);
            return fileData;
        } catch (error) {
            throw new Error('Failed to get recording data');
        }
    }
}

module.exports = new RecordingService();
