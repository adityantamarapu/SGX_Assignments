const { getAllTeams, addNewTeam, addMember, getTeamSearchList, getTeamMembersByTeamName } = require('../models/Team');

class TeamService {
    async getAllTeams() {
        try {
            const teams = await getAllTeams();
            return teams;
        } catch (error) {
            throw new Error('Failed to retrieve teams from the database');
        }
    }

    async createTeam(teamData) {
        try {
            const teamId = await addNewTeam(teamData);
            return teamId;
        } catch (error) {
            throw new Error('Failed to create team');
        }
    }

    async countTeams() {
        try {
            const count = await countTeams();
            return count;
        } catch (error) {
            throw new Error('Failed to count teams');
        }
    }

    async addMemberToTeam(teamId, memberId) {
        try {
            const result = await addMember(teamId, memberId);
            return result;
        } catch (error) {
            throw new Error('Failed to add member to team');
        }
    }

    async getTeamSearchList(searchTerm) {
        try {
            const filteredTeams = await getTeamSearchList(searchTerm);
            return filteredTeams;
        } catch (error) {
            throw new Error('Failed to fetch search list');
        }
    }

    async getTeamMembersByTeamName(teamName) {
        try{
            const members = await getTeamMembersByTeamName(teamName);
            return members;
        }catch(error){
            throw new Error('Failed to fetch members');
        }
    }
}

module.exports = new TeamService();
