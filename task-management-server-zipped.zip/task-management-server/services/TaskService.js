//services/TaskService.js

const { getAllTasks, addNewTask, countTasks, getSearchList, getTasksByTeamName} = require('../models/Task');

class TaskService {
  async getAllTasks() {
    try {

      const tasks = await getAllTasks();
      return tasks;
    } catch (error) {
      throw new Error('Failed to retrieve tasks from the database');
    }
  }

  async createTask(taskData) {
    try {

      const taskId = await addNewTask(taskData);

      return taskId;
    } catch (error) {
      throw new Error('Failed to create task');
    }
  }

  async countTasks() {
    try {
      const count = await countTasks();
      return count;
    } catch (error) {
      throw new Error('Failed to count tasks');
    }
  }

  async getTasksByTeam(teamName) {
    try {
      const tasks = await getTasksByTeamName(teamName);
      return tasks;
    } catch (error) {
      throw new Error('Failed to retrieve tasks by team name');
    }
  }

//   async getSearchList(searchTerm) {
//     try {
//       const filteredTasks = await getSearchList(searchTerm);
//       return filteredTasks;
//     } catch (error) {
//       throw new Error('Failed to fetch search list');
//     }
//   }
}

module.exports = new TaskService();
