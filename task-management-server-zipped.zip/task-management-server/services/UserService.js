//services/UserService.js

const { getAllUsers, addNewUser, countUsers, getSearchList } = require('../models/User');

class UserService {
  async getAllUsers() {
    try {

      const users = await getAllUsers();
      return users;
    } catch (error) {
      throw new Error('Failed to retrieve users from the database');
    }
  }

  async createUser(userData) {
    try {

      const userId = await addNewUser(userData);

      return userId;
    } catch (error) {
      throw new Error('Failed to create user');
    }
  }

  async countUsers() {
    try {
      const count = await countUsers();
      return count;
    } catch (error) {
      throw new Error('Failed to count users');
    }
  }

  async getSearchList(searchTerm) {
    try {
      const filteredUsers = await getSearchList(searchTerm);
      return filteredUsers;
    } catch (error) {
      throw new Error('Failed to fetch search list');
    }
  }
}

module.exports = new UserService();
