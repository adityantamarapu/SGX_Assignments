// auth.service.ts

import { ChangeDetectorRef, Injectable, WritableSignal, inject, signal } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BookingRequest } from './travel-packages.service';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  // public isLoggedIn: WritableSignal<boolean> = signal(false);
  isLoggedInSubject = new BehaviorSubject(false);
  isLoggedIn$ = this.isLoggedInSubject.asObservable();

  public isAdmin: boolean= true;
  public username!: string;
  public id!:number;
  
  private apiUrl = 'http://localhost:8080/api/auth';

  private http = inject(HttpClient);

  login(username: string, password: string): Observable<any> {

    this.username = username;
    
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'X-XSRF-TOKEN': this.getXsrfToken(), 
    });
    const loginForm = { username, password};

    return this.http.post<any>(`${this.apiUrl}/login`, loginForm, {headers, withCredentials: true })
    .pipe(
      tap(res=>{
        this.id = res.id;

        this.isAdmin = res.admin;
        // this.isLoggedIn.set(true);

        // this.setLoggedInState(true);

        console.log('auth service says: ',this.id, res, this.isAdmin);
      })
    );
  }

  register(registerForm: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'X-XSRF-TOKEN': this.getXsrfToken(), 
    });
    return this.http.post<any>(`${this.apiUrl}/register`, registerForm, { headers, withCredentials: true });
  }

  resetPassword(resetToken: string, newPassword: string): Observable<any> {
    const resetForm = { resetToken, newPassword };
    return this.http.post<any>(`${this.apiUrl}/reset-password`, resetForm, { withCredentials: true });
  }

  generateResetToken(username: string): Observable<any> {
    // console.log(this.username);
    // Adjust the API endpoint based on your backend implementation
    return this.http.post<any>(`${this.apiUrl}/forgot-password/${username}`, {}, { withCredentials: true });
  }

  setLoggedInState(newLoginState: boolean): void {

    // this.isLoggedIn.set(newLoginState);
    this.isLoggedInSubject.next(newLoginState);
    console.log('auth service says login state: ', this.isLoggedInSubject.value);
  }

  logout(): void {
    this.http.post<any>(`${this.apiUrl}/logout`, {}, { withCredentials: true }).subscribe(res=>{

      this.setLoggedInState(false);
      console.log('auth service says res: ', res);

      localStorage.removeItem('token');
      console.log('auth logout says token:', localStorage.getItem('token'));

    });

  }

  setId(_id: number){
    this.id= _id;    
    console.log('auth service says id: ', _id, this.id);
  }

  getId() : number{
    console.log('auth service says id: ', this.id);
    return this.id;
  }

  private getXsrfToken(): string {
    const cookieValue = document.cookie
      .split('; ')
      .find(row => row.startsWith('XSRF-TOKEN'))
      ?.split('=')[1] ?? '';

    return decodeURIComponent(cookieValue);
  }

  // bookPackage(bookingData: BookingRequest): Observable<string> {
  //   bookingData.userId = this.id;
  //   console.log('bookPackage says: ',bookingData);
  //   const url = `http://localhost:8080/packages/book`; // Update with your server's endpoint
  //   return this.http.post<string>(url, bookingData);
  // }

}
