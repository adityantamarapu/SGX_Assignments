import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable,  map, catchError  } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TravelPackagesService {
  private apiUrl = 'http://localhost:8080';

  private http = inject(HttpClient);

  getBookedTourismPackages(): Observable<Booking[]> {
    const url = `${this.apiUrl}/bookings`;
    
    return this.http.get<Booking[]>(url)
      .pipe(
        map((response: any) => response),
        catchError(error => {
          console.error('Error fetching booked tourism packages:', error);
          throw error;
        })
      );
  }

  getTourismPackages(): Observable<TourismPackage[]> {
    return this.http.get<TourismPackage[]>(`${this.apiUrl}/api/home/packages`);
  }

  createPackage(packageData: TourismPackage): Observable<TourismPackage> {
    const url = `${this.apiUrl}/admin/packages/create`; // Update with your server's endpoint
    return this.http.post<TourismPackage>(url, packageData);
  }

  bookPackage(bookingData: BookingRequest): Observable<string> {
    console.log('bookPackage says: ',bookingData);
    const url = `${this.apiUrl}/api/home/packages/book`; // Update with your server's endpoint
    return this.http.post<string>(url, bookingData);
  }
 
}

export interface TourismPackage {
  // Define the structure of a tourism package
  id: number;
  name: string;
  description: string;
  images: File[];
  // Add more properties as needed
}

export interface BookingRequest {
  userId: number;
  packageId: number;
  date: Date;
  // Add more properties as needed
}

export interface Booking {
  id: number;
  user: number; 
  tourismPackage: TourismPackage; 
  date: Date;
}