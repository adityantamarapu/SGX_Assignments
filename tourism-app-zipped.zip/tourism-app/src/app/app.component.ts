import { Component, OnInit, computed, inject, } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { AuthService } from './service/auth.service';
// import { LoginComponent } from './component/login/login.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterModule, RouterLink],
  providers: [AuthService,Router],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{
  title = 'tourism-app'; 

  public authService = inject(AuthService);

  isLoggedIn!: boolean;
  
  private route = inject(Router);

  ngOnInit() {

    this.authService.isLoggedIn$.subscribe({
      next: (value)=> {
        this.isLoggedIn = value;
        console.log('app component loggedIn observable subscription says: ', this.isLoggedIn);
      },
      error: (error)=> console.error(error)
    })

    // this.isLoggedIn = this.authService.isLoggedIn();

    // computed(()=>{
    //   this.isLoggedIn = this.authService.isLoggedIn();
    //   console.log('app component says logged in: ', this.isLoggedIn);
    // });

    // setInterval(()=>{
    //   console.log('app component interval says: ', this.authService.id, this.authService.isLoggedIn());
    // },2000);
 
  }

  // handleLogin(){
  //   console.log('handle login called');
  //   this.route.navigate(['/login']); 
  // }

  // handleRegister(){
  //   console.log('handle register called');
  //   this.route.navigate(['/register']); 
  // }

  handleLogout(){
    this.authService.logout();
    console.log('app component logout says: ', this.isLoggedIn);
    // this.route.navigate(['/login']); 
  }
}
