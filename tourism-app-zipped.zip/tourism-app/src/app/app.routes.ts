import { Routes } from '@angular/router';
import { LoginComponent } from './component/login/login.component';
import { RegisterComponent } from './component/register/register.component';
import { ForgotPasswordComponent } from './component/forgot-password/forgot-password.component';
import { UserListComponent } from './component/user-list/user-list.component';
import { HomeComponent } from './component/home/home.component';
import { CreatePackageComponent } from './component/create-package/create-package.component';
import { PackageBookingsComponent } from './component/package-bookings/package-bookings.component';

export const routes: Routes = [
    { path: 'home', component: HomeComponent },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'forgot-password', component: ForgotPasswordComponent },
    { path: 'forgot-password/:username', component: ForgotPasswordComponent },
    { path: 'users', component: UserListComponent },
    { path: 'create-package', component: CreatePackageComponent },
    { path: 'bookings', component: PackageBookingsComponent }
];
