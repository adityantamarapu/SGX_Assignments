import { HttpInterceptorFn } from '@angular/common/http';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const token = localStorage.getItem('token'); // Retrieve token from local storage
    if (token) {
      const authReq = req.clone({
        headers: req.headers.set('Authorization', 'Bearer '+ token),
      })

      return next(authReq);
    }

    console.log('interceptor: ', token)
    
  return next(req);
};
