// import { NgModule } from "@angular/core";
// import { AppComponent } from "./app.component";
// import { HomeComponent } from "./component/home/home.component";
// import { LoginComponent } from "./component/login/login.component";
// import { AuthService } from "./service/auth.service";
// import { UserService } from "./service/user.service";
// import { CreatePackageComponent } from "./component/create-package/create-package.component";
// import { ForgotPasswordComponent } from "./component/forgot-password/forgot-password.component";
// import { RegisterComponent } from "./component/register/register.component";
// import { PackageBookingsComponent } from "./component/package-bookings/package-bookings.component";
// import { UserListComponent } from "./component/user-list/user-list.component";
// import { TravelPackagesService } from "./service/travel-packages.service";
// import { RouterModule } from "@angular/router";
// import { CommonModule } from "@angular/common";
// import { FormsModule } from "@angular/forms";
// import { HttpClientModule } from "@angular/common/http";
// import { BrowserModule } from "@angular/platform-browser";

// @NgModule({
//     declarations: [
//         AppComponent,
//         HomeComponent,
//         LoginComponent,
//         CreatePackageComponent,
//         ForgotPasswordComponent,
//         RegisterComponent,
//         PackageBookingsComponent,
//         UserListComponent,
//         // Add other components here
//     ],
//     imports: [
//         // RouterModule
//         // .forRoot([

//         //     { path: 'home', component: HomeComponent },
//         //     { path: 'login', component: LoginComponent },
//         //     { path: 'register', component: RegisterComponent },
//         //     { path: 'forgot-password', component: ForgotPasswordComponent },
//         //     { path: 'forgot-password/:username', component: ForgotPasswordComponent },
//         //     { path: 'users', component: UserListComponent },
//         //     { path: 'create-package', component: CreatePackageComponent },
//         //     { path: 'bookings', component: PackageBookingsComponent }
//         // ])
//         // ,
//         CommonModule,
//         FormsModule,
//         HttpClientModule,
//         BrowserModule
//     ],
//     providers: [
//         AuthService,
//         UserService,
//         TravelPackagesService
//         // Add other services here
//     ],
//     bootstrap: [AppComponent]
// })
// export class AppModule { }