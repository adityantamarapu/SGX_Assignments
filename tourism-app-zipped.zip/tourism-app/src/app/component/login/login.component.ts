// login.component.ts

import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { AuthService } from '../../service/auth.service';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule],
  providers: [AuthService,Router],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = ''; // New property for error message

  // private authService = inject(AuthService);

  // changeDetectRef = inject(ChangeDetectorRef);
  
  // private router = inject(Router);

  constructor(private router: Router, private authService: AuthService){}

  login(): void {
    if(!this.username || !this.password || this.password.length==0 || this.username.length ==0){
      this.errorMessage = 'Please enter the details.';
      return;
    }
    this.errorMessage = ''; // Clear previous error message

    this.authService.login(this.username, this.password).subscribe(
      response => {

        console.log('login says id : ', response.id); // Handle the response as needed

        this.authService.setId(response.id);

        // For example, you might update the UI based on the response
        if (response && response.status === 'success') {

          const token = response.token;
          localStorage.setItem('token', token);

          console.log('Authentication successful');

          this.authService.setLoggedInState(true);  

          // this.changeDetectRef.detectChanges();

          this.router.navigate(['/home'])
        }
         else {
          // Handle authentication failure
          this.errorMessage = 'Invalid credentials. Please try again.';
          console.log('Authentication failed');
        }
      },
      error => {
        console.error('Error during login:', error);
        this.errorMessage = 'Invalid credentials. Please try again.';
        console.log('Authentication failed');
        // Handle error as needed
      }
    );

  }

  handleForgotPassword(){
    console.log('login component handleForgotPassword says: ', this.username);
    this.router.navigate(['/forgot-password', this.username]);
  }

  
  clearErrorMessage(): void {
    this.errorMessage = '';
  }

  // logChanges(){
  //   console.log('login component logChanges says: ', this.username);
  // }
}
