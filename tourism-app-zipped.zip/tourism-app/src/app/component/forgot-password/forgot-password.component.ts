import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../service/auth.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [AuthService, Router,
    //  ActivatedRoute
    ],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.css'
})
export class ForgotPasswordComponent implements OnInit{
  resetToken: string = '';
  newPassword: string = '';
  confirmPassword: string = '';
  errorMessage: string = '';
  username: string = '';

  // private authService = inject(AuthService);
  // private router = inject(Router);
  // private activatedRoute = inject(ActivatedRoute);

  constructor(private router: Router, private authService: AuthService, private activatedRoute: ActivatedRoute){}
  
  ngOnInit(): void {;
    this.username = this.activatedRoute.snapshot.paramMap.get('username') || '';
    console.log('forgotpass component onInit says: ', this.username);
    this.generateResetToken();
  }

  generateResetToken(): void {
    // Make an HTTP request to your backend endpoint for generating a reset token
    this.authService.generateResetToken(this.username).subscribe(
      response => {
        console.log(response); // Handle the response as needed
        if (response && response.status === 'success') {
          this.resetToken = response.token; // Store the generated reset token
        } else {
          // Handle the case where token generation fails
          console.error('Error generating reset token:', response);
          this.errorMessage= 'Error generating reset token';
        }
      },
      error => {
        // Handle the error
        console.error('Error generating reset token:', error);
        this.errorMessage= 'Error generating reset token';
      }
    );
  }

  resetPassword(): void {
    this.errorMessage = '';

    // Validate the input fields
    if (!this.resetToken || !this.newPassword || !this.confirmPassword) {
      this.errorMessage = 'All fields are required';
      return;
    }

    // Additional validation if needed (e.g., password strength)

    // Check if passwords match
    if (this.newPassword !== this.confirmPassword) {
      this.errorMessage = 'Passwords do not match';
      return;
    }
    

    // Call your AuthService or the service handling password reset in your application
    // This is where you should make an API call to reset the password using the provided token and new password
    this.authService.resetPassword(this.resetToken, this.newPassword).subscribe(
      response => {
        console.log(response); // Handle the response as needed
        if (response && response.status === 'success') {
          console.log('Password reset successful');
          // Optionally, you can navigate to a login page or display a success message
          this.router.navigate(['/login']);
        } else {
          // Handle password reset failure
          this.errorMessage = 'Error resetting password. Please try again.';
          console.log('Password reset failed');
        }
      },
      error => {
        console.error('Error during password reset:', error);
        this.errorMessage = 'Error resetting password. Please try again.';
        console.log('Password reset failed');
        // Handle error as needed
      }
    );
  }

  clearErrorMessage(): void {
    this.errorMessage = '';
  }
}