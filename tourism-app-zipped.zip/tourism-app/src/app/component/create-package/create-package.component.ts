import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TourismPackage, TravelPackagesService } from '../../service/travel-packages.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
// import { SIGNAL } from '@angular/core/primitives/signals';

@Component({
  selector: 'app-create-package',
  standalone: true,
  imports: [ CommonModule, FormsModule],
  providers:[],
  templateUrl: './create-package.component.html',
  styleUrl: './create-package.component.css'
})
export class CreatePackageComponent {

  packageData: TourismPackage = {
    // Initialize with default values if needed
    // Example: name: '', description: '', price: 0, etc.
    id: -1,
    name: '',
    description: '',
    images: []
  };

  errorMessage: string = '';

  private travelPackageService= inject( TravelPackagesService);

  private router = inject( Router);

  createPackage(): void {
      
    if(this.packageData.name.trim() === '' || this.packageData.description.trim() === '') return;

    this.travelPackageService.createPackage(this.packageData).subscribe(
      (response) => {
        console.log('Package created successfully:', response);
        // Redirect or perform other actions after successful creation
        this.packageData.name = '';
        this.packageData.description= '';
        this.router.navigate(['/home']);

      },
      (error) => {
        console.error('Error creating package:', error);
        // Handle error, display a message, etc.
        this.errorMessage = 'Error creating package. Please try again.';
      }
    );
  }

  onFilesSelected(event: any) {
    this.packageData.images = Array.from( event.target.files);
    console.log(this.packageData.images);
  }

  removeImage(index: number): void {
    this.packageData.images.splice(index, 1);
  }
  


}