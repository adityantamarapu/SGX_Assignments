import { Component, inject } from '@angular/core';
import { AuthService } from '../../service/auth.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, HttpClientModule, CommonModule],
  providers: [AuthService],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  username: string = '';
  password: string = '';
  confirmPassword: string = '';
  userRole: boolean = false;
  adminRole: boolean = false;
  registrationSuccess: boolean = false;
  registrationError: string = '';

  private authService = inject(AuthService);
  
  // private router = inject(Router);

  register(): void {

    this.registrationError = '';

    // Check if the password and confirm password match
    if (this.password !== this.confirmPassword) {
      this.registrationError = 'Password and confirm password do not match.';
      return;
    }

    const roles: string[] = [];
    if (this.userRole) {
      roles.push('USER');
    }
    if (this.adminRole) {
      roles.push('ADMIN');
    }

    const registerForm = {
      username: this.username,
      password: this.password,
      roles: roles
    };

    this.authService.register(registerForm).subscribe(
      response => {
        console.log(response);
        if (response && response.status === 'success') {
          // Handle successful registration, e.g., navigate to login page
          console.log('User registration successful', response);
          this.registrationSuccess = true;
        } else {
          // Handle registration failure
          console.log('User registration failed', response);
          this.registrationError = response.error.message;
        }
      },
      error => {
        console.error('Error during registration:', error);
        // Handle error as needed
        this.registrationError = 'Registration failed. Please try again.';
      }
    );
  }
}
