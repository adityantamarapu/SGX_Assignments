import { ChangeDetectionStrategy, Component, OnInit, inject } from '@angular/core';
import { TourismPackage, TravelPackagesService } from '../../service/travel-packages.service';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../service/auth.service';
import { of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule, NgbModule],
  providers: [TravelPackagesService, AuthService],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit{

  tourismPackages: TourismPackage[] = [];

  filteredPackages: TourismPackage[] = [];

  private authService = inject(AuthService);

  private tourismService = inject(TravelPackagesService);

  private router = inject(Router);

  errorMessage: string = '';

  private isLoggedIn! : boolean;

  searchTerm: string = '';

  ngOnInit(): void {
    this.loadTourismPackages();

    this.authService.isLoggedInSubject.subscribe({
      next: (value)=> this.isLoggedIn = value,
      error: (error)=> console.error(error)
    });
    
  }

  loadTourismPackages() {
    this.tourismService.getTourismPackages().subscribe(
      (packages) => {
        this.tourismPackages = packages;
        this.filteredPackages = this.tourismPackages;
      },
      (error) => {
        console.error('Error fetching tourism packages:', error);
      }
    );
  }

  bookPackage(packageId: number): void {
    // For demonstration purposes, you can use a default date (e.g., current date)
    const currentDate = new Date();

    console.log('home says : ', this.isLoggedIn , this.authService.isLoggedInSubject.value);
  
    // Ensure that the user is logged in
    if (!this.isLoggedIn) {
      console.error('User is not logged in.');
      // this.errorMessage = 'User is not logged in.';
      // return;
    }
  
    // Get the user ID
    const userId = this.authService.getId();

  
    // Call the service to book the package
    this.tourismService.bookPackage({
      userId,
      packageId,
      date: currentDate
    }).subscribe(
      response => {
        console.log('Booking successful:', response);
        this.router.navigate(['/bookings']);
        // Optionally, update the UI or show a confirmation message
      },
      error => {
        console.error('Booking failed:', error);
        // Optionally, handle the error and display a message to the user
      }
    );
  }

  onSearchChange() {
    this.filteredPackages = this.tourismPackages.filter(_package=>_package.name.toLowerCase().includes(this.searchTerm.toLowerCase()) || _package.description.toLowerCase().includes(this.searchTerm.toLowerCase()));
    if(this.filteredPackages.length == 0) this.filteredPackages = this.tourismPackages;
    // console.log(this.searchTerm, this.filteredPackages);
  }
  
}