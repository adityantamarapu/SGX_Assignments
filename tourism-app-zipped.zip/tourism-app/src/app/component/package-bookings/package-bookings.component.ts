import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit, inject } from '@angular/core';
import { Booking, TourismPackage, TravelPackagesService } from '../../service/travel-packages.service';
import { AuthService } from '../../service/auth.service';

@Component({
  selector: 'app-package-bookings',
  standalone: true,
  imports: [CommonModule],
  providers:[TravelPackagesService,AuthService],
  templateUrl: './package-bookings.component.html',
  styleUrl: './package-bookings.component.css'
})
export class PackageBookingsComponent implements OnInit {
  bookings!: Booking[]; // Assuming your bookings have a certain structure

  private tourismService = inject(TravelPackagesService);

  private authService  = inject(AuthService);

  ngOnInit(): void {
    this.getBookedTourismPackages();
  }

  getBookedTourismPackages(): void {
    this.tourismService.getBookedTourismPackages()
      .subscribe(
        (bookedPackages: Booking[]) => {
          this.bookings = bookedPackages;
          console.log('Booked Tourism Packages:', this.bookings);
        },
        error => {
          console.error('Error fetching booked tourism packages:', error);
          // Handle the error as needed
        }
      );
  }
}