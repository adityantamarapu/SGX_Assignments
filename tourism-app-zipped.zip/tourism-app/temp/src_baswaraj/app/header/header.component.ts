import { Component } from "@angular/core";

@Component({
    selector:'app-header',
    templateUrl:'./header.Component.html',
    styleUrls:['./header.component.css']
})
export class HeaderComponent{

}