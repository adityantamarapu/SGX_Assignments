import { Component } from '@angular/core';

@Component({
  selector: 'app-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css']
})
export class ContainerComponent {
//   yourName:string='';
//   Name : string = "";
//   product={
//     mobileName :'iPhone 13',
//     Price : 5000,
//     color: 'Black',
//     discount: 10,
//     inStock:10,
//     image:"assets/SChethri.jpg"
//   }


// getDiscountedPrice(){
//   return '$'+(this.product.Price-(this.product.Price*this.product.discount/100))
// }

// onEnter(event:any){ 
//   // console.log(event)
//   this.Name=event.target.value;
// }

// onDecrease(){
//   if(this.product.inStock>0){
//     this.product.inStock-= 1;
//   }
// }
// onIncrease(){
//   this.product.inStock+= 1;
// }
// items:string[]=['One','Two','Three','Four'];
 }

