package com.scc.tourismApp.component;

import lombok.Data;

@Data
public class ResetPasswordForm {
    private String resetToken;
    private String newPassword;
}
