package com.scc.tourismApp.component;

import lombok.Data;

@Data
public class LoginForm {


    private String username;
    private String password;

}
