package com.scc.tourismApp.component;

import com.scc.tourismApp.config.Role;
import lombok.Data;

import java.util.Set;

@Data
public class RegisterForm {

    private String username;
    private String password;

    private String email;

    private Set<Role> roles;
}