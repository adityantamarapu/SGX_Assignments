package com.scc.tourismApp.component;

import lombok.Data;

import java.util.Date;

@Data
public class BookingReq {

    private Long userId;
    private Long packageId;
    private Date date;

}