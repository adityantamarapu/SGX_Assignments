package com.scc.tourismApp.component;

import lombok.Data;

@Data
public class PackageForm {
    private String name;
    private String description;
//    private Integer price;
}
