package com.scc.tourismApp.service;

import com.scc.tourismApp.entity.Token;
import com.scc.tourismApp.entity.User;
import com.scc.tourismApp.repository.TokenRepository;
import com.scc.tourismApp.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.UUID;

@Service
public class PasswordResetService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TokenRepository tokenRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

//    @Autowired
//    private EmailService emailService;

    public String generateResetToken(User user) {
        // Generate a unique reset token, save it in the database, and associate it with the user
        String resetToken = generateUniqueToken();
        Token token = new Token(resetToken, user);

        LocalDateTime expiryDate = LocalDateTime.now().plusHours(24);
        Date expirationDate = Date.from(expiryDate.atZone(ZoneId.systemDefault()).toInstant());

        token.setExpiryDate(expirationDate);

        tokenRepository.save(token);

//        emailService.sendResetTokenEmail(user.getEmail(), "Travel App Password Reset", "Your reset token is: " + resetToken);

        return resetToken;
    }

    public User validateResetTokenAndGetUser(String resetToken) {
        // Validate the reset token and retrieve the associated user
        Token token = tokenRepository.findByResetToken(resetToken);
        if (token != null && !token.isExpired()) {
            return token.getUser();
        }
        return null;
    }

    @Transactional
    public void updatePassword(User user, String newPassword) {
        // Update the user's password and invalidate/reset associated tokens
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);

        // Optionally, invalidate/reset associated tokens
        tokenRepository.deleteByUser(user);
    }

    private String generateUniqueToken() {
        // Logic to generate a unique reset token (e.g., using UUID)
        return UUID.randomUUID().toString();
    }
}
