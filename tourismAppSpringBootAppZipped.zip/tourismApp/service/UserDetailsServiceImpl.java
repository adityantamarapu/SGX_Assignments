package com.scc.tourismApp.service;

import com.scc.tourismApp.config.Role;
import com.scc.tourismApp.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import com.scc.tourismApp.entity.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

        Set<GrantedAuthority> authorities = new HashSet<>();
        for (Role role : user.getAuthorities()) {
            authorities.add(new SimpleGrantedAuthority(role.name()));
        }

        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                authorities
        )
//        {
//            public Long getId() {
//                return user.getId();
//            }
//        }
        ;
    }

    public Optional<User> findUserByName(String username) {
        Optional<User> userOptional = userRepository.findByUsername(username);
        return userOptional;
    }


//    public Optional<User> findUserByEmail(String email) {
//        return userRepository.findByEmail(email);
//    }

    @Transactional
    public void saveUser(User user) {
        userRepository.save(user);
    }

}

