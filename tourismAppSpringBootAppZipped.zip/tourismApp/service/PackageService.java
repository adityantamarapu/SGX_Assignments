package com.scc.tourismApp.service;

import com.scc.tourismApp.component.PackageForm;
import com.scc.tourismApp.entity.Package;
import com.scc.tourismApp.repository.PackageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PackageService {

    @Autowired
    private PackageRepository packageRepository;

    @Autowired
    public PackageService(PackageRepository packageRepository) {
        this.packageRepository = packageRepository;
    }

    public Optional<Package> getPackageById(Long packageId) {
        return packageRepository.findById(packageId);
    }

    public List<Package> getAllPackages() {
        return packageRepository.findAll();
    }

    public Package createPackage(PackageForm _package) {
        // Your package creation logic goes here
        // For example, you might want to set some default values or perform validation
        Package newPackage = new Package();
        newPackage.setName(_package.getName());
        newPackage.setDescription(_package.getDescription());

        // Save the package using the repository
        return packageRepository.save(newPackage);
    }
}
