package com.scc.tourismApp.controller;

import com.scc.tourismApp.component.LoginForm;
import com.scc.tourismApp.component.LoginRes;
import com.scc.tourismApp.component.RegisterForm;
import com.scc.tourismApp.component.ResetPasswordForm;
import com.scc.tourismApp.config.JwtUtil;
import com.scc.tourismApp.config.Role;
import com.scc.tourismApp.entity.User;
import com.scc.tourismApp.service.PasswordResetService;
import com.scc.tourismApp.service.UserDetailsServiceImpl;
import com.scc.tourismApp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200")
public class AuthController {

    @Autowired
    private PasswordResetService passwordResetService;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginForm loginForm) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginForm.getUsername(), loginForm.getPassword())
            );

            System.out.println("/login says: "+ authentication.getName() + " " + authentication.getAuthorities());

            String name = authentication.getName();
            Set<Role> authorities = authentication.getAuthorities().stream().map(e->Role.valueOf(e.getAuthority())).collect(Collectors.toSet());

            User user = new User();
            user.setUsername(name);
            user.setAuthorities(authorities);


            Long id =  userDetailsService.findUserByName(name).orElseThrow(() -> new UsernameNotFoundException("User not found")).getId();

            String token = jwtUtil.createToken(user);

            LoginRes loginRes = new LoginRes(name,token,id);

            System.out.println(loginRes);

            return ResponseEntity.ok().body("{\"status\": \"success\", \"message\": \"User Login successful\" , \"token\": \""+ loginRes.getToken() +"\", \"id\": \""+loginRes.getId()+"\" }");
        } catch (AuthenticationException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Authentication failed");
        }
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody RegisterForm registerForm) {

        if (registerForm.getUsername() == null || registerForm.getPassword() == null) {
            return ResponseEntity.badRequest().body("Invalid input for registration");
        }


        if (userDetailsService.findUserByName(registerForm.getUsername()).isPresent()
//                || userDetailsService.findUserByEmail(registerForm.getEmail()).isPresent()
                ) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Username already exists");
        }


        User newUser = new User();
        newUser.setUsername(registerForm.getUsername());
        newUser.setPassword(passwordEncoder.encode(registerForm.getPassword()));
//        newUser.setEmail(registerForm.getEmail());

        Set<Role> roles = registerForm.getRoles();

//        System.out.println("/register says: " + roles);

        if (roles == null || roles.isEmpty()) {
            roles = Collections.singleton(Role.USER);// Default role if none provided
        }

        newUser.setAuthorities(roles);

        System.out.println("/register says: "+newUser);

        userDetailsService.saveUser(newUser);

        return ResponseEntity.ok().body("{\"status\": \"success\", \"message\": \"User registration successful\"}");
    }

    @PostMapping("/forgot-password/{username}")
    public ResponseEntity<String> forgotPassword(@PathVariable String username) {
        try {
            System.out.println(username);

            // Find the user by email
            User user = userDetailsService.findUserByName(username).orElse(null);

            System.out.println(user);

            // If the user is found, generate a reset token and send it
            if (user != null) {
                String resetToken = passwordResetService.generateResetToken(user);
                return ResponseEntity.ok().body("{\"status\": \"success\", \"message\": \"Reset token generated and sent successfully\" , \"token\": \"" + resetToken + "\"}");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found for the provided email");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error processing forgot password request");
        }
    }

    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordForm resetPasswordForm) {
        try {

            // Validate the reset token and retrieve the associated user
            User user = passwordResetService.validateResetTokenAndGetUser(resetPasswordForm.getResetToken());

            // If the token is valid, update the user's password
            if (user != null) {
                String newPassword = resetPasswordForm.getNewPassword();

                passwordResetService.updatePassword(user, newPassword);

                return ResponseEntity.ok().body("{\"status\": \"success\", \"message\": \"Password reset successful\"}");
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid reset token");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error resetting password");
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        return ResponseEntity.ok("Logout successful");
    }
}
