package com.scc.tourismApp.controller;

import com.scc.tourismApp.component.PackageForm;
import com.scc.tourismApp.entity.Package;
import com.scc.tourismApp.entity.User;
import com.scc.tourismApp.service.PackageService;
import com.scc.tourismApp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private PackageService packageService;

    @GetMapping("/users")
    public List<User> getAllUsers() {

//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//
//        System.out.println("Is authenticated: " + authentication.isAuthenticated());
//
//        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
//        System.out.println("Authorities: " + authorities);

        return userService.getAllUsers();
    }

    @PostMapping("/packages/create")
    public ResponseEntity<String> createPackage(@RequestBody PackageForm packageForm) {
        try {
            if (packageForm == null || packageForm.getName() == null || packageForm.getDescription() == null) {
                return ResponseEntity.badRequest().body("Invalid input for package creation");
            }

            Package createdPackage = packageService.createPackage(packageForm);

            return ResponseEntity.ok().body("{\"status\": \"success\", \"message\": \"Package created successfully\", \"packageId\": " + createdPackage.getId() + "}");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error creating package: " + e.getMessage());
        }
    }

}
