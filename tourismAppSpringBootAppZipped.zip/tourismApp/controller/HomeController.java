package com.scc.tourismApp.controller;

import com.scc.tourismApp.component.BookingReq;
import com.scc.tourismApp.entity.Booking;
import com.scc.tourismApp.entity.Package;
import com.scc.tourismApp.entity.User;
import com.scc.tourismApp.service.BookingService;
import com.scc.tourismApp.service.PackageService;
import com.scc.tourismApp.service.UserDetailsServiceImpl;
import com.scc.tourismApp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/home")
@CrossOrigin(origins = "http://localhost:4200")
public class HomeController {

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @Autowired
    private PackageService packageService;

    @Autowired
    private BookingService bookingService;

    @GetMapping("/packages")
    public ResponseEntity<List<Package>> getPackages() {
        try {
            List<Package> packages = packageService.getAllPackages();
            return ResponseEntity.ok().body(packages);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null); // You can customize the error response
        }
    }

//    @PostMapping("/packages/book")
//    public ResponseEntity<String> createBooking(@RequestBody BookingReq bookingRequest, @AuthenticationPrincipal UserDetails userDetails) {
//        try {
//            // Validate input parameters
//            if (bookingRequest.getUserId() == null || bookingRequest.getPackageId() == null) {
//                return ResponseEntity.badRequest().body("Invalid input parameters");
//            }
//
////            if (userDetails instanceof UserDetailsServiceImpl) {
////                UserDetailsServiceImpl userService = (UserDetailsServiceImpl) userDetails;
////                Optional<User> optionalUser = userService.findUserByName(userDetails.getUsername());
////
////                if (optionalUser.isPresent() && !bookingRequest.getUserId().equals(optionalUser.get().getId())) {
////                    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
////                }
////            }
//
//            // You can customize the logic to get the date as needed
//            Date bookingDate = bookingRequest.getDate();
//
//
//            Booking newBooking = new Booking();
//            newBooking.setUser(userService.getUserById(bookingRequest.getUserId()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found")));
//            newBooking.setTourismPackage(packageService.getPackageById(bookingRequest.getPackageId()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Package not found")));
//            newBooking.setDate(bookingDate);
//
//            bookingService.createBooking(newBooking);
//
//            return ResponseEntity.ok().body("Booking created successfully");
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error creating booking");
//        }
//    }

    @PostMapping("/packages/book")
    public ResponseEntity<String> createBooking(@RequestBody BookingReq bookingRequest     ) {
        try {

            System.out.println(bookingRequest);

            // Validate input parameters
            if (bookingRequest.getPackageId() == null) {
                return ResponseEntity.badRequest().body("Invalid input parameters");
            }

            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

            if (authentication == null || !authentication.isAuthenticated()) {
                // Handle the case where the user is not authenticated
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not authenticated");
            }

//            System.out.println(userDetails);

            // Retrieve the currently logged-in user details
            String username = authentication.getName();
            User loggedInUser = userDetailsService.findUserByName(username)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

            // You can customize the logic to get the date as needed
            Date bookingDate = bookingRequest.getDate();

            Booking newBooking = new Booking();
            newBooking.setUser(loggedInUser);
            newBooking.setTourismPackage(packageService.getPackageById(bookingRequest.getPackageId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Package not found")));
            newBooking.setDate(bookingDate);

            bookingService.createBooking(newBooking);

            return ResponseEntity.ok().body(null);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error creating booking");
        }
    }


}