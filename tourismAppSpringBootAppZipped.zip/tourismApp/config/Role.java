package com.scc.tourismApp.config;

public enum Role {
    USER,
    ADMIN
}
