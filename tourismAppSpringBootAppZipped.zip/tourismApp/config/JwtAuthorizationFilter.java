package com.scc.tourismApp.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.security.core.authority.SimpleGrantedAuthority;


import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class JwtAuthorizationFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;
    private final ObjectMapper mapper;

    public JwtAuthorizationFilter(JwtUtil jwtUtil, ObjectMapper mapper) {
        this.jwtUtil = jwtUtil;
        this.mapper = mapper;
    }
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        Map<String, Object> errorDetails = new HashMap<>();

        try {
            String accessToken = jwtUtil.resolveToken(request);
            if (accessToken == null ) {
                filterChain.doFilter(request, response);
                return;
            }
            System.out.println("do filter says token : "+accessToken);

            Claims claims = jwtUtil.resolveClaims(request);

            System.out.println("do filter says claims: " + claims);

            if(claims != null & jwtUtil.validateClaims(claims)){
                String username = claims.getSubject();
                List<String> roles = jwtUtil.getRoles(claims);
                System.out.println("do filter says name : "+username);

                System.out.println("do filter says roles: "+roles);
                Authentication authentication =
                        new UsernamePasswordAuthenticationToken(username,"",getAuthorities(roles));
                SecurityContextHolder.getContext().setAuthentication(authentication);

                System.out.println("do filter says context: "+ SecurityContextHolder.getContext());
            }

        }catch (Exception e){
            if (!response.isCommitted()) {
                errorDetails.put("message", "Authentication Error");
                errorDetails.put("details", e.getMessage());
                response.setStatus(HttpStatus.FORBIDDEN.value());
                response.setContentType(MediaType.APPLICATION_JSON_VALUE);

                try {
                    if (!response.isCommitted()) mapper.writeValue(response.getWriter(), errorDetails);
                } catch (IOException ioException) {
                    // Handle the exception when writing to response fails
                    ioException.printStackTrace();
                }
            } else {
                // Log the exception or handle it in an appropriate way
                e.printStackTrace();
            }

        }
        filterChain.doFilter(request, response);
    }

    private Collection<? extends GrantedAuthority> getAuthorities(List<String> roles) {
        return roles.stream()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
    }

}