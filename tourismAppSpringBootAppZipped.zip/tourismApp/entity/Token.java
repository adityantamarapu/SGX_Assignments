package com.scc.tourismApp.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Entity
//@Table(name = "tokens")
@Data
public class Token {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "reset_token", unique = true, nullable = false)
    private String resetToken;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "expiry_date", nullable = false)
    private Date expiryDate;

    public Token() {
        // Empty constructor needed by JPA
    }

    public Token(String _resetToken, User _user) {
        resetToken= _resetToken;
        user= _user;
    }

    public boolean isExpired() {
        // Check if the current date is after the expiryDate
        return expiryDate != null && new Date().after(expiryDate);
    }
}
