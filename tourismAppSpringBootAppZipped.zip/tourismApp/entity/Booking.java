package com.scc.tourismApp.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;

@Entity
@Table(name = "bookings")
@Data
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference // Add this annotation to break the loop during serialization
    private User user;

    @ManyToOne
    @JoinColumn(name = "package_id", nullable = false)
    private Package tourismPackage;

    @Temporal(TemporalType.TIMESTAMP)
    private Date date;

//    public Booking(User _userId, Package _packageId, Date _bookingDate) {
//        userId = _userId;
//        packageId= _packageId;
//        date = _bookingDate;
//    }
}