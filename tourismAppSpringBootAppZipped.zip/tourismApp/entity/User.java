package com.scc.tourismApp.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.scc.tourismApp.config.Role;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Singular;

import java.util.List;
import java.util.Set;

@Entity
@Data
@Table(name = "\"user\"")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String username;

    private String password;

//    private String email;

    @ElementCollection(targetClass = Role.class, fetch = FetchType.EAGER)
    @CollectionTable(name = "user_authorities", joinColumns = @JoinColumn(name = "username"))
    @Enumerated(EnumType.STRING)
    @Column(name = "authority")
    private Set<Role> authorities;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    @JsonManagedReference // Add this annotation to break the loop during serialization
    private List<Booking> bookings;

//    @Singular
//    @ManyToMany(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
//    @JoinTable(name = "users_authorities", joinColumns = {
//            @JoinColumn(name = "USERS_ID", referencedColumnName = "ID") }, inverseJoinColumns = {
//            @JoinColumn(name = "AUTHORITIES_ID", referencedColumnName = "ID") })
//    private List<Authority> authorities;

//    public User(){}

}
