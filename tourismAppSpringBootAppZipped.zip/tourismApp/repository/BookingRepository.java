package com.scc.tourismApp.repository;

import com.scc.tourismApp.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    // Add custom query methods if needed

    List<Booking> findByUserId(Long userId);

}
