package com.scc.tourismApp.repository;

import com.scc.tourismApp.entity.Token;
import com.scc.tourismApp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TokenRepository extends JpaRepository<Token, Long> {

    Token findByResetToken(String resetToken);

    // Optionally, you can add additional methods for managing tokens

    // Example method to delete tokens associated with a specific user
    void deleteByUser(User user);
}

