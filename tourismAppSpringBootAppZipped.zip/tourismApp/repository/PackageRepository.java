package com.scc.tourismApp.repository;


import com.scc.tourismApp.entity.Package;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PackageRepository extends JpaRepository<Package, Long> {
    // You can define custom queries or methods here if needed
}
